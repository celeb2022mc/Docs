# importing pandas module
import pandas as pd
from openpyxl import load_workbook
import json
import glob
import http.client

# input excel file path

path="C:\\Users\\503195904\\My Data\\GE-Genpact Confidential\\DevOps\\VMOps_Patching\\PatchingSchedule\\2024\\07072024\\"
Spreadsheet="FW1 Patching"
################################################################
inputExcelFile = path+"CyberOpsPatchPlan.xlsx"
fw=Spreadsheet.split(' ')[0]
print(fw)

# Reading an excel file
excelFile = pd.read_excel (inputExcelFile, sheet_name=Spreadsheet)


ChangeNo = list(excelFile['Change#'].unique())
#print(ChangeNo)

# Create a new DataFrame for each unique value
for TicketNo in ChangeNo:
  print(TicketNo)
  var1=TicketNo
  new_excelFile = excelFile[excelFile['Change#']==TicketNo]
  # Save the new DataFrame to a new spreadsheet
  new_excelFile.to_excel(f'{path}{fw}_{TicketNo}.xlsx', index=False)

##### Retrieving the token
conn = http.client.HTTPSConnection("fssfed.ge.com")
payload = 'client_id=***&client_secret=***&scope=api&grant_type=client_credentials'
headers = {
  'Accept': 'application/json',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Cookie': 'PF=***; PF=***'
}
conn.request("POST", "/fss/as/token.oauth2", payload, headers)
res = conn.getresponse()
data = res.read()
access_data=json.loads(data.decode("utf-8"))
#print(access_data)
accesstoken=access_data["access_token"]
#print(accesstoken)

def GET_SYS_ID(ChgNo):
  conn = http.client.HTTPSConnection("api.ge.com")
  headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' +accesstoken,
    'Cookie': 'PF=***; BIGipServerpool_geitqa=210220042.36414.0000; JSESSIONID=B572BD97DBA0D183F196B0A3B9DB0DE8; glide_session_store=E063406547644250565A8F48436D4351; glide_user_route=glide.99255580fff0a5083a01ba03de72d299'
  }
  #print("/digital/servicenowprodnormalchange/v1/record/"+ChgNo)
  conn.request("GET", "/digital/servicenowprodnormalchange/v1/record/"+ChgNo,headers=headers)
  #conn.request("GET", "/digital/servicenowprodnormalchange/v1/record/GECHG2004258",headers=headers)
  res = conn.getresponse()
  data = res.read()
  #print(data)
  get_result=json.loads(data.decode("utf-8"))
  #print(get_result)
  sysid=get_result['result'][0]['sys_id']
  return sysid
  
def POST_File(sysid,filename,binary_data):
  conn = http.client.HTTPSConnection("api.ge.com")
  print(filename)
  #print(sysid)
  headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/xlsx',
    'Authorization': 'Bearer ' +accesstoken,
    'Cookie': 'PF=***; BIGipServerpool_geitqa=210220042.36414.0000; JSESSIONID=B572BD97DBA0D183F196B0A3B9DB0DE8; glide_session_store=E063406547644250565A8F48436D4351; glide_user_route=glide.99255580fff0a5083a01ba03de72d299'
  }
  url_string="/digital/servicenowattachmentprod/v1/attachment/file?table_name=change_request&table_sys_id="+sysid+"&file_name="+filename
  #print(url_string)
  conn.request("POST", url_string,binary_data,headers=headers)
  res = conn.getresponse()
  data = res.read()
  #print(data)
  post_result=json.loads(data.decode("utf-8"))
  return post_result
 
  
# Extract the list of filenames
files = glob.glob(path + 'FW*.xlsx', recursive=False)
 
# Loop to print the filenames
for file in files:
    print(file)
    with open(file, 'rb') as fileb:
      binary_data = fileb.read()
    filename = file.split('\\')[-1].split(',')[0]
    #print(filename)
    ChgNo=filename.split('_')[1].split('.')[0]
    print(ChgNo) 
    sysid=GET_SYS_ID(ChgNo)
    #print(sysid)
    attach_result=POST_File(sysid,filename,binary_data)
    print(attach_result)
    
    

