# importing pandas module
import pandas as pd
import json
import datetime
import pytz
import glob
from datetime import timedelta
from string_to_date import convert
from openpyxl import load_workbook
from servicenow_payload import create_and_update

# getting excel files from Directory Desktop
path="C:\\Users\\503195904\\My Data\\GE-Genpact Confidential\\DevOps\\VMOps_Patching\\PatchingSchedule\\2024\\07072024\\"
Spreadsheet="FW1 Patching"
################################################################
inputExcelFile = path+"CyberOpsPatchPlan.xlsx"
fw=Spreadsheet.split(' ')[0]
#print(fw)

# Reading an excel file
excelFile = pd.read_excel (inputExcelFile, sheet_name=Spreadsheet)


schedules = list(excelFile['Timing'].unique())
#print(schedules)
print('##################################################################')
for schedule in schedules:
  print(schedule)
  short_desc="CyberOps Win " +fw +" " +schedule
  utc=pytz.utc 
  var1=schedule.split('-')[0].strip()
  Assets_list=",".join(excelFile[excelFile['Timing']==schedule]['Asset ID'].astype(str))
  print(Assets_list)
  parse_time=convert(var1).astimezone(utc)
  print(parse_time)
  adj_time= parse_time + timedelta(hours=6)
  end_time= str(adj_time)
  start_time= str(parse_time)
  #print("start_time:"+start_time)
  #print("end_time:"+end_time)
  print("short_desc:"+short_desc)
  ticket_no=create_and_update(Assets_list,start_time,end_time,short_desc)
  print(ticket_no)
  #Update the value in the 'Change#' column for all rows matching the 'Timing" column
  #ERROR## excelFile['Change#'] = excelFile['Change#'].where(excelFile['Timing']==schedule,ticket_no)
  excelFile.loc[excelFile["Timing"] == schedule, "Change#"] = ticket_no
  #Save the DataFrame back to the Excel spreadsheet
  excelFile.to_excel(inputExcelFile, sheet_name=Spreadsheet, index=False)
  print('##################################################################')
    
