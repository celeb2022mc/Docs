import http.client
import json

##### Retrieving the token
conn = http.client.HTTPSConnection("fssfed.ge.com")
payload = 'client_id=***&client_secret=***&scope=api&grant_type=client_credentials'
headers = {
  'Accept': 'application/json',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Cookie': 'PF=***; PF=***'
}
conn.request("POST", "/fss/as/token.oauth2", payload, headers)
res = conn.getresponse()
data = res.read()
access_data=json.loads(data.decode("utf-8"))
#print(access_data)
accesstoken=access_data["access_token"]
print(accesstoken)

def create_and_update(Assets_list,start_time,end_time,short_desc):
  #print(Assets_list)
  #print("start_time:"+start_time)
  #print("end_time:"+end_time)
  #print("short_desc:"+short_desc)
  ##### Creating Normal Change
  conn = http.client.HTTPSConnection("api.ge.com")
  payload = json.dumps({
    "insert": {
      "partnerInfo": {
        "name": "CyberOps VPG - Corporate",
        "externalRecord": "10"
      },
      "type": "Normal",
      "requested_by": "503195904",
      "cmdb_ci": "1100933215",
      "affected_cis": Assets_list,
      "start_date": start_time,
      "end_date": end_time,
      "short_description": short_desc,
      "description": "Apply the latest  patches for attached  servers.",
      "justification": "Remediation of vulns per BU request.",
      "assigned_to": "503195904",
      "work_notes": "This is only a test.",   
      "assignment_group": "@CORP CyberOps Dev"
    }
  })
  headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' +accesstoken,
    'Cookie': 'PF=RiVy6hZYyOYz39OyHH00En; BIGipServerpool_geitqa=210220042.36414.0000; JSESSIONID=B572BD97DBA0D183F196B0A3B9DB0DE8; glide_session_store=E063406547644250565A8F48436D4351; glide_user_route=glide.99255580fff0a5083a01ba03de72d299'
  }
  #print(payload)
  conn.request("POST", "/digital/servicenowprodnormalchange/v1", payload, headers)
  res = conn.getresponse()
  data = res.read()
  #print(data)
  create_result=json.loads(data.decode("utf-8"))
  print(create_result)
  #print(snow_ticket)
  #print(create_result['result']['number'])
  snow_ticket=create_result['result']['number']

  ##### Update Normal Change

  conn = http.client.HTTPSConnection("api.ge.com")
  payload = json.dumps({
  "update" : {
      "partnerInfo": {
        "name": "CyberOps VPG - Corporate",
        "externalRecord": "10"
      },
      "number": snow_ticket,
      "state": "Assess",
      "assigned_to": "503195904",
      "implementation_plan": "@CORP CyberOps VPG Patching Assignment Group will apply the latest recommended patching for targeted Win Servers. Servers being patched will be in use from the moment the maintenance window begins until the very minute the maintenance window closes.",
      "backout_plan": "Rollback patching. Remove new version if installed and install previous version.",
      "test_plan": "Application owners are responsible for testing the applications post patching  after the maintenance window is complete.",
      }
  })

  headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' +accesstoken,
    'Cookie': 'PF=***; BIGipServerpool_geitqa=210220042.36414.0000; JSESSIONID=B572BD97DBA0D183F196B0A3B9DB0DE8; glide_session_store=E063406547644250565A8F48436D4351; glide_user_route=glide.99255580fff0a5083a01ba03de72d299'
  }
  conn.request("PUT", "/digital/servicenowprodnormalchange/v1", payload, headers)
  res = conn.getresponse()
  data = res.read()
  update_result=json.loads(data.decode("utf-8"))
  print(update_result)
  return snow_ticket 


