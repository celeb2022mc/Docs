import datetime
import json
from datetime import timedelta

#Funcation to validate the time format
def is_valid_datetime(date_str, format_str):
    try:
        datetime.datetime.strptime(date_str, format_str)
        return True
    except ValueError:
        return False
        
# Function to convert string to datetime
def convert(date_time):
    format1 = '%A, %B %d: %H'
    format2 = '%A, %B %d: %H:%M'
    if(is_valid_datetime(date_time,format1)):
        datetime_str = datetime.datetime.strptime(date_time, format1).replace(year=datetime.date.today().year)
    else:
        datetime_str = datetime.datetime.strptime(date_time, format2).replace(year=datetime.date.today().year)
 
    return datetime_str
   
#t = 'Saturday, February 24: 06'




