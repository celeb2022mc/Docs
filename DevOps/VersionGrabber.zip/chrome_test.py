from bs4 import BeautifulSoup
import requests
import json
from selenium import webdriver
from selenium.webdriver import ChromeOptions, chrome
from selenium.webdriver.support.ui import WebDriverWait
import os, time
#   from . import config

opts = ChromeOptions()                                       
opts.add_experimental_option("detach", True)                  
opts.add_argument('disable-infobars')
opts.add_argument('--ignore-certificate-errors')
opts.add_argument('--ignore-certificate-errors-spki-list')
opts.add_argument('--ignore-ssl-errors')

DRIVER_PATH = "C:\\Users\\503195904\\My Data\\GE-Genpact Confidential\\DevOps\\Automation\\Mohan_WebScrapping\\ChromeDriver\\chromedriver.exe"
driver = webdriver.Chrome(executable_path=DRIVER_PATH,options=opts)
driver.maximize_window()

def Chrome():
    url = "https://omahaproxy.appspot.com/?_sm_au_=i5VMfD4FJWDRV0VRML8tvK34L00HF"
    driver.get(url)
    window_0 = driver.window_handles[0]
    driver.switch_to_window
    time.sleep(30)
    html=driver.page_source
    r = requests.get(url)
    soup = BeautifulSoup(html,"html.parser")
 

    release_notes = soup.find("table").find_all("tr")
    col = release_notes[2].find_all("td")
    data={}
    data['Software'] = "Google Chrome"
    data['UpdateLevel'] = col[2].text.strip()
    data['Version'] = data['UpdateLevel'].split(".")[0]
    data['ReleaseDate'] = col[4].text.strip()   
       #To send to API use
    chrome_rel_data = data

    

    #with open('chrome_json.json', 'w') as outfile:
    #json.dump(chrome_rel_data, outfile)
    print(chrome_rel_data)    
    return chrome_rel_data
#config.all_versions.append(Chrome())
Chrome()


      