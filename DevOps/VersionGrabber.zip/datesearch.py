from dateparser.search import search_dates

results=()
results=search_dates("10.3.4.0.5 Patch Set Update (PSU) for WebLogic Server 10.3.4.0 April 2012 was the FINAL patch for 10.3.4")
#data=results[1].split(",")[0].strip() + " " + results[2].split(",")[0].strip()
data=str(results[1]).split(",")[0].strip("'").split("(")[1].strip("'") + "," + str(results[2]).split(",")[0].strip("'").split("(")[1].strip("'")
print(data)
