import glob
import importlib.util
from datetime import datetime, timedelta, date
from pathlib import Path
import json
from MainPackage import config



modules = []
editions = []


def loadModules(folder = 'MainPackage', name = None):
    del modules[:]
    del editions[:]
    
    pattern = '[!_]*' if name == None else name
    data_folder = Path(folder)
    
    for filename in data_folder.glob(pattern + ".py"):
        if filename.stem != "config":
            module = importlib.import_module(folder + "." + filename.stem)
            modules.append(module)
    #print(modules)
    of_=open('versiongrab_latest.json','w')
    json.dump(config.all_versions,of_)
    of_.close()
    
    config.all_versions=[]
    
        
	#return modules
    
loadModules()

