from bs4 import BeautifulSoup
import requests
import json
from . import config

links = []
data = {}
def JDK8():
    url = "https://www.oracle.com/java/technologies/javase/8u-relnotes.html"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")

    html_parse1 = soup.find_all("ul", class_="cta-list")
    line = html_parse1[0].find_all('li')

    #links = []
    for link in line[0].find_all('a'):
        links.append("https://www.oracle.com"+link.get('href'))
    sub_link = links[0].strip()
    #print(sub_link)

    sr = requests.get(sub_link)
    sub_soup = BeautifulSoup(sr.content,"html5lib")
    html_parse2 = sub_soup.find_all("div", class_="cc01w1 cwidth")
    row = html_parse2[0].find_all('p')
    #print(row)
    for i in range(len(row)):
        if i==0:
            data['Software'] = "Java"
            data['ReleaseDate'] = row[0].text.strip()
        elif i==1:
            data['UpdateLevel'] = row[1].text.strip().split("release is")[1].strip().split(" ")[0].strip()
            data['Version'] = data['UpdateLevel'][0]

    #print(data)
    JDK8_Json_data=data
    #with open('JDK8_json.json', 'w') as outfile:
    #    json.dump(JDK8_Json_data,outfile)

    #return(JDK8_Json_data)
    return(JDK8_Json_data)

config.all_versions.append(JDK8())
