from bs4 import BeautifulSoup
import requests
import json
from . import config

def Adobe():
    url = "https://helpx.adobe.com/acrobat/release-note/release-notes-acrobat-reader.html"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")
    # release_info = []

    release_notes = soup.find("table").find_all("tr")
    # for row in release_notes:
    col = release_notes[1].find_all("td")
    data={}

    version = None

    ###############################################
    if ("xx" in col[1].text.strip()):
        sub_link = release_notes[1].find('a')["href"]
        sub_r = requests.get(sub_link)
        sub_sop = BeautifulSoup(sub_r.content,"html5lib")
        

        versionInfo = sub_sop.find('div',attrs={
            "id":"available-installers"
        }).p.text
        versionInfo = versionInfo.split(" ")
        
        for i in range(len(versionInfo)):
            if versionInfo[i].strip() == "win":
                version = versionInfo[i+1].strip('()')
                break          
                
    ###############################################

    for i in range(len(col)):
        if i==0:
            data['Software'] = "Adobe Acrobat Reader"
            data['ReleaseDate'] = col[i].text.strip()
        elif i==1:
            data['UpdateLevel'] = version or col[i].text.strip().split(" ")[-1].strip("()")
            data['Version'] = data['UpdateLevel'].split(".")[0]
        else: 
            data['focus']=col[i].text.strip()
            string_encode=data['focus'].encode("ascii","ignore")
            string_decode=string_encode.decode()
            data["focus"]=string_decode
    # release_info.append(data)

    #To send to API use
    adobe_rel_data = data

    #adobe_rel_data = data
    

    #with open('adobe_json.json', 'w') as outfile:
    #    json.dump(adobe_rel_data, outfile)
    
    return adobe_rel_data

config.all_versions.append(Adobe())


      