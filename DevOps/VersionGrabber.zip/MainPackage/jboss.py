from requests import Session
from bs4 import BeautifulSoup
import requests
import json
from selenium import webdriver
from selenium.webdriver import ChromeOptions, chrome
from selenium.webdriver.support.ui import WebDriverWait
import os, time
from . import config

opts = ChromeOptions()                                       
opts.add_experimental_option("detach", True)                  
opts.add_argument('disable-infobars')
opts.add_argument('--ignore-certificate-errors')
opts.add_argument('--ignore-certificate-errors-spki-list')
opts.add_argument('--ignore-ssl-errors')

DRIVER_PATH = "C:\\Users\\503195904\\My Data\\GE-Genpact Confidential\\DevOps\\Automation\\Mohan_WebScrapping\\ChromeDriver\\chromedriver.exe"
driver = webdriver.Chrome(executable_path=DRIVER_PATH,options=opts)
driver.maximize_window()

url = "https://access.redhat.com/errata/#/?q=&p=1&sort=portal_publication_date%20desc&rows=10&portal_advisory_type=Security%20Advisory&portal_product=JBoss%20Enterprise%20Application%20Platform&portal_product_version=7.3"
driver.get(url)
window_0 = driver.window_handles[0]
driver.switch_to_window
time.sleep(8)

html=driver.page_source
soup = BeautifulSoup(html,"html.parser")
#print(soup)
parse = soup.find("table").find_all("tr")
rel_note=parse[1].find_all("td")

data={}
for i in range(len(rel_note)):
    if i==1:
        data['Software'] = "Jboss EAP"
        data['UpdateLevel'] = rel_note[1].find("span",class_="cell-content ng-binding").text.strip("security update").split(" ")[-1].strip()
        data['Version'] = data['UpdateLevel'].split(".")[0]
        data['Release_Update'] = rel_note[1].find("span",class_="cell-content ng-binding").text.strip()
    if i==4:
        data['ReleaseDate'] = rel_note[4].find("time",class_="ng-binding").text.strip()

jboss_release_data = data

#with open('jboss_json.json','w') as outfile:
#    json.dump(jboss_release_data,outfile)
config.all_versions.append(jboss_release_data)
driver.close()
driver.quit()

   

      