from bs4 import BeautifulSoup
import requests
import json
from . import config

def Corretto8():
    url = "https://docs.aws.amazon.com/corretto/latest/corretto-8-ug/doc-history.html"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")
    # release_info = []

    release_notes = soup.find("table").find_all("tr")
    # for row in release_notes:
    col = release_notes[1].find_all("td")
    data={}

 
    for i in range(len(col)):
        if i==0:
            data['Software'] = "corretto-8"
            data['UpdateLevel'] = col[i].text.strip().split(" ")[-1].strip()
            data['Version'] = data['UpdateLevel'].split(".")[0]
        elif i==1:
            data['description'] = col[i].text.strip()
        else:
            data['ReleaseDate'] = col[i].text.strip()
    
    #data.update({'url':url})
        

    #To send to API use
    corretto8_rel_data = data

    #adobe_rel_data = data
    

    #with open('corretto8_json.json', 'w') as outfile:
    #    json.dump(corretto8_rel_data, outfile)
    
    return corretto8_rel_data
config.all_versions.append(Corretto8())


      