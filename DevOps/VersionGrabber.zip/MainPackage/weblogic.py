from requests import Session
from bs4 import BeautifulSoup
import requests
import json
from selenium import webdriver
from selenium.webdriver import ChromeOptions, chrome
from selenium.webdriver.support.ui import WebDriverWait
import os, time
from . import config
from dateparser.search import search_dates

opts = ChromeOptions()                                       
opts.add_experimental_option("detach", True)                  
opts.add_argument('disable-infobars')
opts.add_argument('--ignore-certificate-errors')
opts.add_argument('--ignore-certificate-errors-spki-list')
opts.add_argument('--ignore-ssl-errors')

DRIVER_PATH = "C:\\Users\\503195904\\My Data\\GE-Genpact Confidential\\DevOps\\Automation\\Mohan_WebScrapping\\ChromeDriver\\chromedriver.exe"
driver = webdriver.Chrome(executable_path=DRIVER_PATH,options=opts)
driver.maximize_window()

url = "https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=208871019157941&id=1470197.1&_adf.ctrl-state=17ej7fu976_60"
driver.get(url)
window_0 = driver.window_handles[0]
driver.switch_to_window
driver.find_element_by_id("sso_username").clear()
driver.find_element_by_id("sso_username").send_keys("mohan.chinthala@ge.com")
driver.find_element_by_id("ssopassword").clear()
driver.find_element_by_id("ssopassword").send_keys("******")
driver.find_element_by_id("signin_button").click()

#WebDriverWait(driver=driver, timeout=10).until(
#    lambda x: x.execute_script("return document.readyState === 'complete'")
#)

# get the errors (if there are)
#error_message = "Invalid username"
#errors = driver.find_elements_by_class_name("cb41error")
#if any(error_message in e.text for e in errors):
#    print("[!] Login failed")
#else:
#    print("[+] Login successful")

time.sleep(10)


html=driver.page_source
soup = BeautifulSoup(html,"html.parser")
#print(soup)
release_notes = soup.find_all("table",class_="km")
#print(release_notes)
#print(range(len(release_notes)))
release_data={}
# release_list=[]
i=0

for i in range(len(release_notes)):
    data_parse=release_notes[i].find_all("tr")
    col=data_parse[1].find_all("td")
    for n in range(len(col)):
        if n==0:
            release_data['Software'] = "Oracle Weblogic"
            release_data['UpdateLevel']=col[n].text.strip()
        elif n==1:
            release_data['Version']=col[n].text.strip().split(" ")[-1].strip()
            #release_data['Description']=col[n].text.strip()
            data=col[n].text.strip()
            results=()
            results=search_dates(data)

            p1=str(results).strip("[]").split("))")[0].split(",")[0].strip("('")
            if p1=="Set":
                reldate=str(results).strip("[]").split(")),")[1].split(",")[0].strip(" ('")
            else:
                reldate=p1
            #print(reldate)

            release_data['ReleaseDate']=str(reldate)
            release_data['Description']=data
            
        
    data=json.dumps(release_data)
    # release_list.append(json.loads(data))
    config.all_versions.append(json.loads(data))


driver.close()
driver.quit()