from bs4 import BeautifulSoup
import requests
import json
from . import config

def Firefox():
    url = "https://www.mozilla.org/en-US/firefox/releases/"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")
    # release_info = []

    release_notes = soup.find("ol",class_="c-release-list").find_all("li")

    sub_link = url+release_notes[0].find('a')["href"].strip()
    sub_r = requests.get(sub_link)
    sub_soup = BeautifulSoup(sub_r.content,"html5lib")

    data = {}
    data['Software'] = "Mozilla Firefox"
    data['UpdateLevel'] = sub_soup.find("div",class_="c-release-version").text.strip()
    data['Version'] = data['UpdateLevel'].split(".")[0]
    data['ReleaseDate']      = sub_soup.find("p",class_="c-release-date").text.strip()
    data['product']   = sub_soup.find("div",class_="c-release-product").text.strip()
 


    firefox_release_data = data

    #with open('firefox_json.json','w') as outfile:
    #    json.dump(firefox_release_data,outfile)

    return(firefox_release_data)


config.all_versions.append(Firefox())


      