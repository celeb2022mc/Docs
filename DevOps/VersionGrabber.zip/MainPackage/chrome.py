from bs4 import BeautifulSoup
import requests
import json
from . import config

def Chrome():
    url = "https://support.google.com/chrome/a/answer/7679408/"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")
 

    release_notes = soup.find("table").find_all("tr")
    col = release_notes[1].find_all("td")
    data={}
    data['Software'] = "Google Chrome"
    data['UpdateLevel'] = col[0].text.strip().split(":")[0].split(" ")[-1].strip()
    data['Version'] = data['UpdateLevel'].split(".")[0]
    data['ReleaseDate'] = col[0].text.strip().split(":")[1].strip()    
       #To send to API use
    chrome_rel_data = data

    

   # with open('chrome_json.json', 'w') as outfile:
   #     json.dump(chrome_rel_data, outfile)
    
    return chrome_rel_data
config.all_versions.append(Chrome())


      