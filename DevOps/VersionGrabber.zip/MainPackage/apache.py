from bs4 import BeautifulSoup
import requests
import json
from . import config

def Apache():
    url = "http://httpd.apache.org/download.cgi"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")
 
    data={}
    data['Software'] = "Apache HTTP Server"
    data['UpdateLevel'] = soup.find('div',attrs={"id":"apcontents"}).ul.li.text.split(" ")[0].strip()
    version_prefix=data['UpdateLevel'].split(".")[:-1]
    data['Version']='.'.join(version_prefix)
    data['ReleaseDate'] = soup.find('div',attrs={"id":"apcontents"}).ul.li.text.split(" ")[-1].split(")")[0]
        

    #To send to API use
    apache_rel_data = data
    

    #with open('apache_json.json', 'w') as outfile:
    #    json.dump(apache_rel_data, outfile)
    
    return apache_rel_data

config.all_versions.append(Apache())


      