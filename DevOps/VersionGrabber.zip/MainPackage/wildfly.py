from bs4 import BeautifulSoup
import requests
import json
from . import config

def Wildfly():
    url = "https://www.wildfly.org/downloads/"

    r = requests.get(url)
    soup = BeautifulSoup(r.content,"html5lib")
    # release_info = []
    data={}
    data['Software'] = "WildFly"
    data['UpdateLevel'] = soup.find("div",class_="grid__item width-2-12 version-id").h2.text.strip(".Final").strip()
    data['Version'] = data['UpdateLevel'].split(".")[0]
    data['ReleaseDate'] = soup.find("span",class_="release-date").text.strip()


    wildfly_rel_data=data

    #with open('wildfly_json.json','w') as outfile:
    #    json.dump(wildfly_rel_data,outfile)

    
    return wildfly_rel_data

config.all_versions.append(Wildfly())



      